from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_sdk import Action
from rasa_sdk.events import SlotSet
from rasa_sdk.events import UserUtteranceReverted
import zomatopy
import json
import pandas as pd
import smtplib
from email.message import EmailMessage
from threading import Thread
from time import sleep

################################################################################################################
# ActionSearchRestaurants class for custom action action_search_restaurants, this function seach the zamoto api for restaurant
# and stores the data in dataframe, creaed new budget column for checking the budget
# then sort the dataframe on rating
###############################################################################################################

class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_search_restaurants'
	
		
	def run(self, dispatcher, tracker, domain):
		config={ "user_key":"f4924dc9ad672ee8c4f8c84743301af5"}
		# initialize the zomoto with key
		zomato = zomatopy.initialize_app(config)

		# get locaiton
		loc = tracker.get_slot('location')

		# get cuisine
		cuisine = tracker.get_slot('cuisine')
		
		# get budget
		budget = tracker.get_slot('price')
		budget1 = budget.lower()
		
		location_detail=zomato.get_location(loc, 1)
		d1 = json.loads(location_detail)
		lat=d1["location_suggestions"][0]["latitude"]
		lon=d1["location_suggestions"][0]["longitude"]
		cuisines_dict={'chinese':25,'italian':55,'north_indian':50,'south_indian':85, 'american': 1, 'mexican': 73}

		# call zomato api
		results=zomato.restaurant_search("", lat, lon, str(cuisines_dict.get(cuisine)), 200)

		d = json.loads(results)
		restaurants = d['restaurants']
		response = "" 

		# global restaurant dataframe
		global restaurants_df
		restaurants_df = pd.DataFrame([{'restaurant_name': rest['restaurant']['name'], \
						'restaurant_address': rest['restaurant']['location']['address'], \
						'average_cost_for_two': rest['restaurant']['average_cost_for_two'], \
						'restaurant_average_rating': rest['restaurant']['user_rating']['aggregate_rating']}
						 for rest in restaurants])
		
		# lambda function for budget
		def budgetize(row):
			if row['average_cost_for_two'] < 300:
                		return 'lesser than rs 300'
			elif row['average_cost_for_two'] > 700:
                		return 'more than 700'
			else:
                		return 'rs 300 to 700'

		## create a new column budget 
		restaurants_df['budget'] = restaurants_df.apply(lambda row: budgetize(row), axis=1)

		## filter on budget
		restaurants_df = restaurants_df[(restaurants_df['budget'] == budget1)]

		## sort the dataframe based on rating
		restaurants_df = restaurants_df.sort_values(['restaurant_average_rating'], ascending = 0)
		
		# get five restaurant
		
		five_restaurants = restaurants_df[:5]
		
		
		# send response
		response = "Here are the top results for you: "+ "\n" + "\n"
		if len(restaurants_df) == 0:
			response= "We are so sorry, we do not have any results for you right now. for price " + budget
			dispatcher.utter_message(response)
			
		else:
			five_restaurants = restaurants_df[:5]
			for index, restaurant in five_restaurants.iterrows():
				response = response + restaurant['restaurant_name'] + \
					  " in " + restaurant['restaurant_address'] + \
					  " has been rated " +  restaurant['restaurant_average_rating'] +  "\n"
					
			dispatcher.utter_message(response)
			

# global service cities list		
serviceable_cities = ['bangalore','chennai','delhi','hyderabad','Kolkata','mumbai','ahmedabad','pune', 'cochi',
      'agra','ajmer','aligarh','amravati','amritsar','asansol','aurangabad','bareilly','belgaum',
      'bhavnagar','bhiwandi','bhopal','bhubaneswar','bikaner','bilaspur','bokaro Steel City',
      'chandigarh','coimbatore','nagpur','cuttack','dehradun','dhanbad','bhilai','durgapur',
      'erode','faridabad','firozabad','ghaziabad','gorakhpur','gulbarga','guntur','gwalior',
      'gurgaon','guwahati','hamirpur','hubli–Dharwad','hubli','dharwad','indore','jabalpur',
      'jaipur','jalandhar','jammu','jamnagar','jamshedpur','jhansi','jodhpur','kakinada',
      'kannur','kanpur','kottayam','kolhapur','kollam','kozhikode','kurnool','ludhian',
      'lucknow','madurai','malappuram','mathura','goa','mangalore','meerut','moradabad',
      'mysore','nanded','nashik','nellore','noida','palakkad','patna','perinthalmanna',
      'pondicherry','purulia Prayagraj','raipur','rajkot','rajahmundry','ranchi','rourkela',
      'salem','sangli','shimla','siliguri','solapur','srinagar','thiruvananthapuram','thrissur',
      'tiruchirappalli','tirur','tirupati','tirunelveli','tiruppur','tiruvannamalai','ujjain',
      'bijapur','vadodara','varanasi','vasai-Virar City','vijayawada','vellore','warangal',
      'surat','visakhapatnam']

################################################################################################################
# CityChecker class for custom action action_check_locaiton , this function checks the location entity is in service cities.
# before that it convert the entity location to lower then check in service cities global list
###############################################################################################################

class CityChecker(Action):
	def name(self):
		return 'action_check_location'

	def run(self, dispatcher, tracker, domain):
		location = tracker.get_slot('location')
		if location is not None:
			if type(location) == str:
				if location.lower() in serviceable_cities:
					print("City is serviceable.")
					return [SlotSet('location', location),SlotSet('location_match','one')]
		print("City is not serviceable.")
		return [SlotSet('location', None), SlotSet('location_match','zero')]


################################################################################################################
# class EmailRestaurantDetails for custom action_send_email, this function sends email
###############################################################################################################
class EmailRestaurantDetails(Action):
	def name(self):
		return 'action_send_email'
	def sendEmail(self,email_id):
		
		msg = EmailMessage()
		
		ten_restaurants = restaurants_df[:10]
		# ten_restaurants = five_restaurants 
		response = " Here are the top 10 restaurants \n \n"
		# concatenate all the ten records in to response
		for index, restaurant in ten_restaurants.iterrows():
			response = response + " NAME: " + restaurant['restaurant_name'] + \
					  ", LOCATION: " + restaurant['restaurant_address'] + \
					  ", AVERAGE BUDGET FOR TWO PEOPLE: " + str(restaurant['average_cost_for_two']) + \
					  ", RATING: "+ str(restaurant['restaurant_average_rating']) +  "\n \n"	
		
		msg.set_content(response)
		msg['Subject'] = f'Top 10 Restaurants'
		msg['From'] = 'rekha060770@gmail.com'
		msg['To'] = str(email_id)

		s = smtplib.SMTP('64.233.184.108',587)
		try:
			s.starttls()
			s.login("rekha060770@gmail.com","suresha1971")
			s.send_message(msg)
		except Exception as e:
			print(str(e))
		s.quit()



	def run(self, dispatcher, tracker, domain):
		# start a thread to send mail
		recipient = tracker.get_slot('emailid')
		thread1 = Thread(target=self.sendEmail,args=(recipient,))
		thread1.start()
		thread1.join()
		
		