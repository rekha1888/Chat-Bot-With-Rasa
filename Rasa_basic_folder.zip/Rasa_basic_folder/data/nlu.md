## intent:affirm
- yes
- yep
- yeah
- indeed
- that's right
- ok
- great
- right, thank you
- correct
- great choice
- sounds really good
- thanks
- thanks
- oki
- great
- great
- send to [rekha07@gmail](emailid)
- yes, please send to [rekha06@gmail.com](emailid)
- please send to [rekha07@gmail.com](emailid)
- yes please send
- send to [saket.garg66@gmail.com](emailid)
- please send

## intent:deny
- No
- no, thanks
- noo
- nope
- no, not required
- thanks, but not required
- i don't require it over mail, thanks
- Don't need email
- Not needed
- no not needed
- no
- no
- no
- no
- no
- no
- no
- no

## intent:goodbye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good one

## intent:greet
- hey
- howdy
- hey there
- hello
- hi
- good morning
- good evening
- dear sir
- hi
- hi
- hello
- hi
- hi
- hi
- hola
- hello
- hello
- hello
- howdy
- good morning
- hey
- hey
- hi
- hi
- hi
- hi
- hi
- hi
- hi
- hi
- hi
- hi
- hi

## intent:inform
- send to [rudrashakarreddy@gmail.com](emailid)
- email it to [saketgarg66@gmail.com](emailid)
- mail it to [saketgarg66@gmail.com](emailid)
- send me at [krsreddy80@gmail.com](emailid)
- send to id [rudrashakarreddy@gmail.com](emailid)

## intent:restaurant_search
- I am looking a restaurant in [294328](location)
- I am looking for [asian fusion](cuisine) food
- I am looking for [mexican indian fusion](cuisine)
- I am looking for some restaurants in [Bangalore](location)
- I am looking for some restaurants in [Delhi](location).
- I am looking for some restaurants in [Mumbai](location)
- I am searching for a dinner spot
- I am searching for a dinner spot
- I want to grab lunch
- I want to have dinner with family
- Looking for a place for family dinner
- Oh, sorry, in [Italy](location)
- Please find me a restaurantin [Bangalore](location)
- [american](cuisine)
- [Bengaluru](location:Bangalore)
- [chinese](cuisine)
- [italian](cuisine)
- [Lesser than Rs 300](price)
- [Lesser than Rs. 300](price:Lesser than Rs 300)
- [Lithuania](location)
- [mexican](cuisine)
- [More than 700](price)
- [north_indian](cuisine)
- [Rs 300 to 700](price) range
- [Rs. 300 to 700](price:Rs 300 to 700)
- [south_indian](cuisine)
- [bangalore](location:Bangalore)
- [central](location) [mexican](cuisine) restaurant
- [chinese](cuisine)
- [delhi](location:Delhi)
- [mumbai](location:Mumbai)
- anywhere in [delhi](location)
- anywhere in the [west](location)
- can you find me a [chinese](cuisine) restaurant
- change it to [Chinese](cuisine:chinese)
- close to [bangalore](location:Bangalore)
- close to [delhi](location:Delhi)
- find me a restaurant
- find me a [chinese](cuisine) in delhi(location)
- find me a [chinese](cuisine) in delhi(location) for price [Lesser than Rs. 300](price:Lesser than Rs 300)
- i am looking for an [south_indian](cuisine) spot called olaolaolaolaolaola
- i'm looking for a place to eat
- in [Gurgaon](location)
- in [delhi](location:Delhi)
- please find me [chinese](cuisine) restaurant in [Delhi](location)
- please find me [chinese](cuisine) restaurant in [Delhi](location) between range [Lesser than Rs. 300](price:Lesser than Rs 300)
- please find me [chinese](cuisine) restaurant in [Delhi](location) between range [More than 700](price)
- please find me [chinese](cuisine) restaurant in [Delhi](location) between range [Rs. 300 to 700](price:Rs 300 to 700)
- please find me a restaurant in [Ahmedabad](location)
- please help me to find restaurants in [Pune](location)
- please show me a few [italian](cuisine) restaurants in [Bangalore](location)
- prefer [American](cuisine)
- search for restaurants
- show me [chines](cuisine:chinese) restaurants in the [New Delhi](location:Delhi)
- show me [chinese](cuisine) restaurants
- show me a [mexican](cuisine) place in the [centre](location)
- show me restaurants
- somewhere in [Delhi](location)
- find restaurant in [Kolkata](location)
- find me restaurants in [Bangalore](location)
- [american](cuisine)
- [Rs. 300 to 700](price:Rs 300 to 700)
- find me restaurants in [Bangalore](location)
- [american](cuisine)
- change cuisine to [mexican](cuisine)
- [More than 700](price)
- [Bangalore](location)
- [Chennai](location)
- [Delhi](location)
- [Hyderabad](location)
- [Kolkata](location)
- [Mumbai](location)
- [Ahmedabad](location)
- [Pune](location)
- [Kochi](location)
- [Agra](location)
- [Ajmer](location)
- [Aligarh](location)
- [Amravati](location)
- [Amritsar](location)
- [Asansol](location)
- [Aurangabad](location)
- [Bareilly](location)
- [Belgaum](location)
- [Bhavnagar](location)
- [Bhiwandi](location)
- [Bhopal](location)
- [Bhubaneswar](location)
- [Bikaner](location)
- [Bilaspur](location)
- [Bokaro Steel City](location)
- [Chandigarh](location)
- [Coimbatore](location)
- [Nagpur](location)
- [Cuttack](location)
- [Dehradun](location)
- [Dhanbad](location)
- [Bhilai](location)
- [Durgapur](location)
- [Erode](location)
- [Faridabad](location)
- [Firozabad](location)
- [Ghaziabad](location)
- [Gorakhpur](location)
- [Gulbarga](location)
- [Guntur](location)
- [Gwalior](location)
- [Gurgaon](location)
- [Guwahati](location)
- [Hamirpur](location)
- [Hubli–Dharwad](location)
- [Hubli](location)
- [Dharwad](location)
- [Indore](location)
- [Jabalpur](location)
- [Jaipur](location)
- [Jalandhar](location)
- [Jammu](location)
- [Jamnagar](location)
- [Jamshedpur](location)
- [Jhansi](location)
- [Jodhpur](location)
- [Kakinada](location)
- [Kannur](location)
- [Kanpur](location)
- [Kottayam](location)
- [Kolhapur](location)
- [Kollam](location)
- [Kozhikode](location)
- [Kurnool](location)
- [Ludhian](location)
- [Lucknow](location)
- [Madurai](location)
- [Malappuram](location)
- [Mathura](location)
- [Goa](location)
- [Mangalore](location)
- [Meerut](location)
- [Moradabad](location)
- [Mysore](location)
- [Nanded](location)
- [Nashik](location)
- [Nellore](location)
- [Noida](location)
- [Palakkad](location)
- [Patna](location)
- [Perinthalmanna](location)
- [Pondicherry](location)
- [Purulia Prayagraj](location)
- [Raipur](location)
- [Rajkot](location)
- [Rajahmundry](location)
- [Ranchi](location)
- [Rourkela](location)
- [Salem](location)
- [Sangli](location)
- [Shimla](location)
- [Siliguri](location)
- [Solapur](location)
- [Srinagar](location)
- [Thiruvananthapuram](location)
- [Thrissur](location)
- [Tiruchirappalli](location)
- [Tirur](location)
- [Tirupati](location)
- [Tirunelveli](location)
- [Tiruppur](location)
- [Tiruvannamalai](location)
- [Ujjain](location)
- [Bijapur](location)
- [Vadodara](location)
- [Varanasi](location)
- [Vasai-Virar City](location)
- [Vijayawada](location)
- [Vellore](location)
- [Warangal](location)
- [Surat](location)
- [Visakhapatnam](location)
- find [chinese](cuisine) restaurant in [Delhi](location)
- [Rs 300 to 700](price)
- find [chinese](cuisine) restaurant in [shimoga](location)
- [delhi](location:Delhi)
- [Rs 300 to 700](price)
- find [chinese](cuisine) restaurant in [delhi](location:Delhi) for price [Rs 300 to 700](price)
- find [chinese](cuisine) restaurant in shimoga for price [Rs 300 to 700](price)
- [delhi](location:Delhi)
- find restaurant
- [heldi](location)
- find [chinese](cuisine) restaurant in [delhi](location:Delhi)
- [Lesser than Rs 300](price)
- [Rs 300 to 700](price)
- [300 to 700](price:Rs 300 to 700)
- [< 300](price:Lesser than Rs 300)
- [> 700](price:More than 700)
- find [chinese](cuisine) restaurant for price [< 300](price:Lesser than Rs 300)
- [shimoga](location)
- [delhi](location:Delhi)
- [300 to 700](price:Rs 300 to 700)
- find [chinese](cuisine) restaurant for price [300 to 700](price:Rs 300 to 700)
- [shimoga](location)
- [delhi](location:Delhi)
- find [chinese](cuisine) restaurant in [shimoga](location) for price range [300 to 700](price:Rs 300 to 700)
- [delhi](location:Delhi)
- [Kalkota](location:Kolkata)
- [kalkota](location:Kolkata)
- find me restaurant in [Calcatta](location:Kolkata)

## synonym:Bangalore
- Bengaluru
- bangalore
- bengaluru

## synonym:Chennai
- Madras
- madras
- chenni

## synonym:Delhi
- delhi
- New Delhi

## synonym:Dharwad
- darwad
- Darwad
- dharwad

## synonym:Kolkata
- Calcutta
- Kalkata
- Calcata

## synonym:Lesser than Rs 300
- Lesser than Rs. 300
- < 300
- lesser than 300
- less than rs 300

## synonym:Mangalore
- Mangaluru
- mangaluru
- mangalore

## synonym:More than 700
- > 700
- more than 700
- more than Rs 700
- more than rs 700

## synonym:Mumbai
- mumbai
- Bombay
- bombay

## synonym:Rs 300 to 700
- Rs. 300 to 700
- 300 to 700
- betweeen 300 to 700
- rs 300 to 700

## synonym:american
- American

## synonym:chinese
- Chinese
- chines
- Chines

## synonym:cochi
- cochin
- kochi
- ernakulam
- Cochin
- Kochi
- Ernakulam

## synonym:italian
- Italian

## synonym:mexican
- Mexican

## synonym:north_indian
- north indian
- North Indian

## synonym:south_indian
- south indian
- South Indian

## synonym:vegetarian
- veggie
- vegg

## regex:emailid
- '\S+@\S+'

## regex:greet
- hey[^\s]*
