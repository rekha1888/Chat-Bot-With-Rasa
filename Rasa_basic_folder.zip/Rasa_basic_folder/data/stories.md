## greet
* greet
    - utter_greet

## greet+Bye
* greet
    - utter_greet
* goodbye
    - utter_goodbye

## story1
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - action_check_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"price": "Rs 300 to 700"}
    - slot{"price": "Rs 300 to 700"}
    - action_search_restaurants
    - slot{"location": "delhi"}
    - utter_ask_send_email
* affirm
    - utter_ask_email
* affirm{"emailid": "rekha060770@gmail"}
    - slot{"emailid": "rekha060770@gmail"}
    - action_send_email
    - utter_goodbye

## story_2
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "delhi"}
    - slot{"location": "delhi"}
    - action_check_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"price": "Rs 300 to 700"}
    - slot{"price": "Rs 300 to 700"}
    - action_search_restaurants
    - slot{"location": "delhi"}
    - utter_ask_send_email
* affirm{"emailid": "rekha060770@@gmail.com"}
    - slot{"emailid": "rekha060770@gmail.com"}
    - action_send_email
    - utter_goodbye

## story_3
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - action_check_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_budget
* restaurant_search{"price": "Lesser than Rs 300"}
    - slot{"price": "Lesser than Rs 300"}
    - action_search_restaurants
    - slot{"location": "bangalore"}
    - utter_ask_send_email
* affirm{"emailid": "rekha060770@gmail.com"}
    - slot{"emailid": "rekha060770@gmail.com"}
    - action_send_email
    - utter_goodbye

## story_4
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - action_check_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_budget
* restaurant_search{"price": "Rs 300 to 700"}
    - slot{"price": "Rs 300 to 700"}
    - action_search_restaurants
    - slot{"location": "bangalore"}
    - utter_ask_send_email
* affirm
    - utter_ask_email
* inform{"emailid": "rekha060770@gmail.com"}
    - slot{"emailid": "rekha060770@gmail.com"}
    - action_send_email
    - utter_goodbye

## story_5
* greet
    - utter_greet
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_check_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_budget
* restaurant_search{"price": "Rs 300 to 700"}
    - slot{"price": "Rs 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Bangalore"}
    - utter_ask_send_email
* deny
    - utter_goodbye

## story_6
* greet
    - utter_greet
* restaurant_search{"location": "Bangalore"}
    - slot{"location": "Bangalore"}
    - action_check_location
    - slot{"location_match": "one"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - slot{"cuisine": "american"}
    - utter_ask_budget
* restaurant_search{"cuisine": "mexican"}
    - slot{"cuisine": "mexican"}
    - utter_ask_budget
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_search_restaurants
    - slot{"location": "Bangalore"}
    - utter_ask_send_email
* affirm
    - utter_ask_email
* inform{"emailid": "rekha060770@gmail.com"}
    - slot{"emailid": "rekha060770@gmail.com"}
    - action_send_email
    - utter_goodbye

## story_7
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Shimoga"}
    - slot{"location": "Shimoga"}
    - action_check_location
    - slot{"location": null}
    - slot{"location_match": "zero"}
    - utter_sorry_dont_operate
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_search_restaurants
    - slot{"location": "Bangalore"}
    - utter_ask_send_email
* affirm
    - utter_ask_email
* inform{"emailid": "rekha060770@gmail.com"}
    - slot{"emailid": "rekha060770@gmail.com"}
    - action_send_email
    - utter_goodbye
    
## story-8
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"location": "Shimoga"}
    - slot{"location": "Shimoga"}
    - action_check_location
    - slot{"location": null}
    - slot{"location_match": "zero"}
    - utter_sorry_dont_operate
* restaurant_search{"location": "bangalore"}
    - slot{"location": "bangalore"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "chinese"}
    - slot{"cuisine": "chinese"}
    - utter_ask_budget
* restaurant_search{"price": "More than 700"}
    - slot{"price": "More than 700"}
    - action_search_restaurants
    - slot{"location": "Bangalore"}
    - utter_ask_send_email
* deny
    - utter_goodbye

## story_9
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "Delhi"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Delhi"}
    - action_check_location
    - slot{"location": "Delhi"}
    - slot{"location_match": "one"}
    - utter_ask_budget
* restaurant_search{"price": "Rs 300 to 700"}
    - slot{"price": "Rs 300 to 700"}
    - action_search_restaurants
    - utter_ask_send_email
* deny
    - utter_goodbye

## story_10
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "shimoga"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "shimoga"}
    - action_check_location
    - slot{"location": null}
    - slot{"location_match": "zero"}
    - utter_sorry_dont_operate
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - slot{"location_match": "one"}
    - utter_ask_budget
* restaurant_search{"price": "Rs 300 to 700"}
    - slot{"price": "Rs 300 to 700"}
    - action_search_restaurants
    - utter_ask_send_email
* deny
    - utter_goodbye

## story-11
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "Delhi", "price": "Rs 300 to 700"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Delhi"}
    - slot{"price": "Rs 300 to 700"}
    - action_check_location
    - slot{"location": "Delhi"}
    - slot{"location_match": "one"}
    - action_search_restaurants
    - utter_ask_send_email
* affirm
    - utter_ask_email
* inform{"emailid": "rekha060770@gmail.com"}
    - slot{"emailid": "rekha060770@gmail.com"}
    - action_send_email
    - utter_goodbye

## story_13
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "price": "Rs 300 to 700"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "Rs 300 to 700"}
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - action_check_location
    - slot{"location": "Delhi"}
    - slot{"location_match": "one"}
    - action_search_restaurants
    - utter_ask_send_email
* deny
    - utter_goodbye


## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "price": "Rs 300 to 700"}
    - slot{"cuisine": "chinese"}
    - slot{"price": "Rs 300 to 700"}
    - utter_ask_location
* restaurant_search{"location": "shimoga"}
    - slot{"location": "shimoga"}
    - action_check_location
    - slot{"location": null}
    - slot{"location_match": "zero"}
    - utter_sorry_dont_operate
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - action_check_location
    - slot{"location": "Delhi"}
    - slot{"location_match": "one"}
    - action_search_restaurants
    - utter_ask_send_email
* deny
    - utter_goodbye

## interactive_story_1
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "shimoga", "price": "Rs 300 to 700"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "shimoga"}
    - slot{"price": "Rs 300 to 700"}
    - action_check_location
    - slot{"location": null}
    - slot{"location_match": "zero"}
    - utter_sorry_dont_operate
* restaurant_search{"location": "Delhi"}
    - slot{"location": "Delhi"}
    - action_check_location
    - slot{"location": "Delhi"}
    - slot{"location_match": "one"}
    - action_search_restaurants
    - utter_ask_send_email
* deny
    - utter_goodbye
